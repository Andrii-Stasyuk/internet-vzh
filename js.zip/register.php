<?php
if(!empty($_POST["button"])==true){
    $firstname=$_POST["firstname"];
    $lastname=$_POST["lastname"];
    $email=$_POST["email"];
    $password=md5($_POST["password"]);
    // $call="INSERT INTO `users`(`Id`, `firstname`, `lastname`, `email`, `password`) VALUES (null,'$firstname','$lastname','$email','$password')";
    require "db_conect.php";
    $mysqli->query("INSERT INTO `users`(`Id`, `firstname`, `lastname`, `email`, `password`,) VALUES (null,'$firstname','$lastname','$email','$password')");
    echo '<script>window.location.href="index.php"</script>';
   }
   
?>